-- This file handles various MysteryHunt things, such as corpses, voice, player list, etc.
local stored_corpse_data = {}

-- shows the number of players (or corpses) in a course (not including self)
-- level and area only apply in b3313 (level also applies in some other scenarios)
-- act, if unset, allows for any act
-- used with radar
function get_player_and_corpse_count(course, level, area, act)
    if gGlobalSyncTable.mhMode ~= 3 then return 0, false end
    local count = 0
    local isB3313 = (ROMHACK and ROMHACK.name == "B3313")
    local isHunter = (gPlayerSyncTable[0].team ~= 1 and (gGlobalSyncTable.anarchy ~= 3 or gPlayerSyncTable[0].spectator == 1)) -- if true, only show alive runners here

    for i = 1, MAX_PLAYERS - 1 do
        local np = gNetworkPlayers[i]
        local sMario = gPlayerSyncTable[i]
        if np.connected and sMario.spectator ~= 1 and np.currCourseNum == course and (act == nil or np.currActNum == act) then
            local valid = true
            if isB3313 and (level ~= np.currLevelNum or area ~= np.currAreaIndex) then
                valid = false
            elseif (level == LEVEL_BOWSER_1 or level == LEVEL_BOWSER_2 or level == LEVEL_BOWSER_3) and level ~= np.currLevelNum then
                valid = false
            elseif isHunter and sMario.team ~= 1 then
                valid = false
            end
            if valid then
                count = count + 1
            end
        end
    end
    if not isHunter then
        for gIndex, data in pairs(stored_corpse_data) do
            local index = network_local_index_from_global(gIndex)
            if index ~= 255 then
                local sMario = gPlayerSyncTable[index]
                if sMario.knownDead == false and sMario.spectator == 1 and data.course == course and (act == nil or data.act == act) then
                    local valid = true
                    if isB3313 and (level ~= data.level or area ~= data.area) then
                        valid = false
                    elseif (level == LEVEL_BOWSER_1 or level == LEVEL_BOWSER_2 or level == LEVEL_BOWSER_3) and level ~= data.level then
                        valid = false
                    end
                    if valid then
                        count = count + 1
                    end
                end
            end
        end
    end
    return count, isHunter
end

function on_character_sound(m, charSound)
    if gGlobalSyncTable.mhMode ~= 3 or m.playerIndex == 0 then return end
    return 0
end

hook_event(HOOK_CHARACTER_SOUND, on_character_sound)

function mystery_popup_off()
    return gGlobalSyncTable.mhMode == 3 and gPlayerSyncTable[0].spectator ~= 1 and gGlobalSyncTable.mhState ~= 0 and
        gGlobalSyncTable.mhState < 3
end

local player_model_table = {
    [CT_MARIO] = E_MODEL_MARIO,
    [CT_LUIGI] = E_MODEL_LUIGI,
    [CT_TOAD] = E_MODEL_TOAD_PLAYER,
    [CT_WALUIGI] = E_MODEL_WALUIGI,
    [CT_WARIO] = E_MODEL_WARIO,
}

-- spawns the local player's corpse object and sends a packet to other players (this way, they can leave the level and still find the corpse later)
function spawn_my_corpse()
    ---@type MarioState
    local m = gMarioStates[0]
    local sMario = gPlayerSyncTable[0]
    local np = gNetworkPlayers[0]
    local model = player_model_table[m.character.type] or E_MODEL_MARIO
    if charSelectExists then
        local charTable = charSelect.character_get_current_table()
        model = (charTable and charTable.model) or model
    end
    local pose = m.marioObj.header.gfx.animInfo.animID
    if pose == MARIO_ANIM_DROWNING_PART1 or pose == MARIO_ANIM_DROWNING_PART2 or pose == MARIO_ANIM_WATER_DYING then
        pose = MARIO_ANIM_DYING_ON_STOMACH
    elseif pose ~= MARIO_ANIM_DYING_ON_BACK and pose ~= MARIO_ANIM_DYING_ON_STOMACH and pose ~= MARIO_ANIM_SUFFOCATING and pose ~= MARIO_ANIM_DYING_FALL_OVER and pose ~= MARIO_ANIM_ELECTROCUTION then
        pose = MARIO_ANIM_DYING_ON_STOMACH
    end

    local corpseData = {
        id = PACKET_CORPSE,
        gIndex = np.globalIndex,
        x = math.floor(m.pos.x),
        y = math.floor(m.pos.y),
        z = math.floor(m.pos.z),
        yaw = m.faceAngle.y,
        pose = pose,
        model = model,
        course = np.currCourseNum,
        level = np.currLevelNum,
        area = np.currAreaIndex,
        act = np.currActNum
    }
    network_send_include_self(true, corpseData)
    local o = spawn_sync_object(id_bhvMHCorpse, model, m.pos.x, m.pos.y, m.pos.z, nil)
    if o then
        o.globalPlayerIndex = np.globalIndex
        o.oBehParams = np.globalIndex + 1
        o.oBobombBlinkTimer = pose
        o.oFaceAngleYaw = m.faceAngle.y
        network_send_object(o, true)
    end
    sMario.knownDead = false
    spectate_command("")
end

-- sent to other players when someone dies
function on_packet_corpse(data, self)
    stored_corpse_data[data.gIndex] = data
end

function on_packet_request_corpses(data, self)
    if #stored_corpse_data then
        for gIndex, data2 in pairs(stored_corpse_data) do
            network_send_to(data.gIndex, true, data2)
        end
    end
end

---@param o Object
function mh_corpse_init(o)
    o.oFlags = o.oFlags | (OBJ_FLAG_UPDATE_GFX_POS_AND_ANGLE | OBJ_FLAG_COMPUTE_DIST_TO_MARIO)
    o.oOpacity = 255
    o.oWallHitboxRadius, o.oGravity, o.oBounciness, o.oDragStrength, o.oFriction, o.oBuoyancy = 40, -4, 0, 10, 10, 8
    o.oFaceAnglePitch = 0
    o.oFaceAngleRoll = 0
    network_init_object(o, true, { 'oBehParams', 'oBobombBlinkTimer' })
end

---@param o Object
function mh_corpse_loop(o)
    local np = network_player_from_global_index(o.oBehParams - 1)
    if not np then
        if o.oTimer > 30 and is_nearest_mario_state_to_object(gMarioStates[0], o) ~= 0 then
            obj_mark_for_deletion(o)
        end
        return
    elseif (not np.connected) and gPlayerSyncTable[np.localIndex].spectator ~= 1 or gPlayerSyncTable[np.localIndex].knownDead then
        obj_mark_for_deletion(o)
        return
    end
    o.globalPlayerIndex = o.oBehParams - 1
    ---@type MarioState
    local m = gMarioStates[np.localIndex]
    local pose = o.oBobombBlinkTimer

    local m0 = gMarioStates[0]
    if gPlayerSyncTable[0].spectator ~= 1 and m0.controller.buttonPressed & L_TRIG ~= 0 and dist_between_objects(m0.marioObj, o) < 200 then
        network_send_include_self(true, {
            id = PACKET_REPORT_BODY,
            reported = network_global_index_from_local(0),
            dead = o.oBehParams - 1,
        })
        obj_mark_for_deletion(o)
        return
    end

    cur_obj_update_floor_and_walls()
    cur_obj_move_standard(-78)
    if o.oMoveFlags & OBJ_MOVE_MASK_IN_WATER ~= 0 then
        pose = MARIO_ANIM_DROWNING_PART2
    elseif o.oMoveFlags & OBJ_MOVE_IN_AIR ~= 0 then
        if o.oFloor == nil or is_hazard_floor(o.oFloorType) then
            pose = MARIO_ANIM_DROWNING_PART2
            o.oVelY = -o.oGravity
        elseif pose ~= MARIO_ANIM_DYING_ON_BACK then
            pose = MARIO_ANIM_AIR_FORWARD_KB
        else
            pose = MARIO_ANIM_BACKWARD_AIR_KB
        end
    end

    if m.marioObj.header.gfx.animInfo.animID ~= pose then
        set_mario_animation(m, pose)
        set_anim_to_frame(m, m.marioObj.header.gfx.animInfo.curAnim.loopEnd)
    end
    m.marioBodyState.eyeState = MARIO_EYES_DEAD
    m.marioBodyState.modelState = 0
    m.fadeWarpOpacity = 255
    o.oOpacity = 255
    
    o.header.gfx.animInfo.animID = m.marioObj.header.gfx.animInfo.animID
    o.header.gfx.animInfo.curAnim = m.marioObj.header.gfx.animInfo.curAnim
    o.header.gfx.animInfo.animYTrans = m.unkB0
    o.header.gfx.animInfo.animAccel = m.marioObj.header.gfx.animInfo.animAccel
    o.header.gfx.animInfo.animFrame = m.marioObj.header.gfx.animInfo.curAnim.loopEnd
end

id_bhvMHCorpse = hook_behavior(nil, OBJ_LIST_GENACTOR, true, mh_corpse_init, mh_corpse_loop, "bhvMHCorpse")

-- respawn corpses on enter
function on_sync_valid()
    if gGlobalSyncTable.mhMode ~= 3 or (gGlobalSyncTable.mhState ~= 1 and gGlobalSyncTable.mhState ~= 2) then
        stored_corpse_data = {}
        return
    end

    local np0 = gNetworkPlayers[0]
    for gIndex, data in pairs(stored_corpse_data) do
        local index = network_local_index_from_global(gIndex)
        if index ~= 255 then
            local sMario = gPlayerSyncTable[index]
            if sMario.knownDead == false and sMario.spectator == 1 and data.level == np0.currLevelNum and data.area == np0.currAreaIndex and data.act == np0.currActNum then
                if (not obj_get_first_with_behavior_id_and_field_s32(id_bhvMHCorpse, 0x40, gIndex + 1)) and get_network_player_smallest_global() == np0 then
                    local o = spawn_sync_object(id_bhvMHCorpse, data.model, data.x, data.y, data.z, nil)
                    if o then
                        o.globalPlayerIndex = gIndex
                        o.oBehParams = gIndex + 1
                        o.oBobombBlinkTimer = data.pose
                        o.oFaceAngleYaw = data.yaw
                        network_send_object(o, true)
                    end
                end
            end
        end
    end
end
hook_event(HOOK_ON_SYNC_VALID, on_sync_valid)

function on_packet_report_body(data, self)
    play_sound(SOUND_OBJ_BOWSER_LAUGH, gGlobalSoundSource)
    local np = network_player_from_global_index(data.reported)
    local np2 = network_player_from_global_index(data.dead)
    local playerColor = network_get_player_text_color_string(np.localIndex)
    local playerColor2 = network_get_player_text_color_string(np2.localIndex)
    local name = playerColor .. np.name
    local name2 = playerColor2 .. np2.name

    local text = trans("report_body", name, name2)
    text = text .. get_custom_level_name(np.currCourseNum, np.currLevelNum, np.currAreaIndex)
    if np.currActNum ~= 0 then
        text = text .. " #" .. tostring(np.currActNum)
    end
    text = text .. "!"
    djui_chat_message_create(text)
    gPlayerSyncTable[np2.localIndex].knownDead = true
    if gGlobalSyncTable.maxGlobalTalk ~= 0 and gGlobalSyncTable.maxGlobalTalk ~= -1 then
        djui_chat_message_create(trans("global_talk_start", gGlobalSyncTable.maxGlobalTalk//30))
        if network_is_server() then
            gGlobalSyncTable.globalTalkTimer = gGlobalSyncTable.maxGlobalTalk
        end
    end
end