local unMod = false
local bad_version = false
local myRoles = 0
local ROLE_POWERS = 1
local ROLE_LEAD = 2
local ROLE_DEV = 4
local ROLE_TRANS = 8
local ROLE_CONT = 16
local ROLE_PLACE = 32
local ROLE_PLACE_ASN = 64
function check_for_roles()
	local discordID = get_local_discord_id()
	local roles = {
		[409438020870078486] = ROLE_POWERS | ROLE_LEAD,
		[1243666680304107565] = ROLE_DEV,
		[705161240657395763] = ROLE_DEV | ROLE_POWERS,
		[572658876223062016] = ROLE_DEV | ROLE_POWERS,
		[990768765652308058] = ROLE_DEV | ROLE_POWERS,
		[698849755274543204] = ROLE_DEV | ROLE_POWERS | ROLE_TRANS,
		[607357462391160895] = ROLE_DEV | ROLE_POWERS,
		[680910843608563776] = ROLE_DEV | ROLE_POWERS,
		[376426041788465173] = ROLE_CONT,
		[584329002689363968] = ROLE_CONT | ROLE_TRANS,
		[552452422740607011] = ROLE_CONT,
		[799106550874243083] = ROLE_TRANS,
		[489114867215630336] = ROLE_TRANS,
		[821532141820444673] = ROLE_TRANS,
		[356531273449078784] = ROLE_TRANS,
		[1142250487089991691] = ROLE_TRANS,
		[392762182154059777] = ROLE_TRANS,
		[708287786813358120] = ROLE_TRANS,
		[336143045395218433] = ROLE_TRANS,
		[897124449608929291] = ROLE_CONT,
		[678794043018182675] = ROLE_CONT
	}
	local role = roles[tonumber(discordID)] or 0
	if role == 0 and gNetworkPlayers[0].name == "EmeraldLockdown" then
		role = ROLE_DEV
	end
	if gPlayerSyncTable[0].placement ~= 9999 then
		role = role | ROLE_PLACE
	end
	if gPlayerSyncTable[0].placementASN ~= 9999 then
		role = role | ROLE_PLACE_ASN
	end
	local shownRoles = tonumber(mod_storage_load("showRoles")) or role
	gPlayerSyncTable[0].role = role & tonumber(shownRoles)
	myRoles = role
	bad_version = VERSION_NUMBER < 37
	local pirate_test = mod_storage_load("piracyTest") == "1"
	local pirate = false
	if pirate_test or pirate or bad_version then
		hook_event(HOOK_ON_HUD_RENDER, anti_steal)
	end
end
function has_mod_powers(index, dev)
	if unMod then
		return false
	end
	if not dev and (network_is_server() or network_is_moderator()) then
		return true
	end
	if index == 0 then
		return myRoles & ROLE_POWERS ~= 0
	else
		local sMario = gPlayerSyncTable[index]
		return sMario.role & ROLE_POWERS ~= 0
	end
end
function unmod()
	unMod = not unMod
	return true
end
function anti_steal()
	djui_hud_set_resolution(RESOLUTION_N64)
	djui_hud_set_font(FONT_NORMAL)
	gGlobalSyncTable.mhState = 0
	gMarioStates[0].freeze = true
	local screenWidth = djui_hud_get_screen_width()
	local screenHeight = djui_hud_get_screen_height()
	play_secondary_music(SEQ_MENU_TITLE_SCREEN | SEQ_VARIATION, 0, 100, 60)
	djui_hud_set_color(0, 0, 0, 255)
	djui_hud_render_rect(0, 0, screenWidth + 5, screenHeight + 5)
	djui_hud_set_font(FONT_HUD)
	local text = "INSERT PIRACY JOKE"
	if bad_version then
		text = "omg plz update"
	end
	local width = djui_hud_measure_text(text) / 2
	local x = screenWidth / 2 - width
	local y = 30
	djui_hud_set_color(255, 255, 255, 255)
	djui_hud_print_text(text, x, y, 1)
	if yyy == nil then
		yyy = 0
	end
	yyy = yyy + 1
	if yyy > 600 and not bad_version then
		djui_hud_render_texture(get_texture_info("title_texture_0A0001C0"), 0, 0, 1, 1)
	end
	local textLines = {
		"You do not have permission to host this version",
		"of MarioHunt.",
		"",
		"If you believe this is a mistake, relaunch with Discord.",
		"Otherwise, download the latest version from GitHub instead."
	}
	if bad_version then
		if SM64COOPDX_VERSION then
			textLines = {
				"Your version of sm64coopdx is OUTDATED!",
				"",
				"Earliest supported version: v1.0",
				"Your version: " .. SM64COOPDX_VERSION,
				"",
				"Please download sm64coopdx v1.0,",
				"or download v2.6.2 (old edition)",
				"of this mod.",
				"",
				"If you are unsure how to update,",
				"check the sm64coopdx discord server."
			}
		else
			textLines = {
				"sm64ex-coop has merged with sm64coopdx.",
				"Please download sm64coopdx v1.0,",
				"or download v2.6.2 (old edition)",
				"of this mod.",
				"",
				"If you are unsure how to update,",
				"check the sm64coopdx discord server."
			}
		end
	elseif yyy > 590 then
		if yyy == 591 then
			play_character_sound(gMarioStates[0], CHAR_SOUND_WAAAOOOW)
		end
		textLines = {
			"You do not have permission to survive"
		}
	end
	djui_hud_set_font(FONT_NORMAL)
	y = 50
	for i, line in ipairs(textLines) do
		text = line
		width = djui_hud_measure_text(text) / 4
		x = screenWidth / 2 - width
		y = y + 15
		djui_hud_set_color(255, 255, 255, 255)
		djui_hud_print_text(text, x, y, 0.5)
	end
end
function get_tag(index)
	local sMario = gPlayerSyncTable[index]
	local tag = ""
	local role = sMario.role or 0
	if role & ROLE_LEAD ~= 0 then
		tag = tag .. trans("role_lead") .. " "
	end
	if role & ROLE_DEV ~= 0 then
		tag = tag .. trans("role_dev") .. " "
	end
	if role & ROLE_CONT ~= 0 then
		tag = tag .. trans("role_cont") .. " "
	end
	if role & ROLE_TRANS ~= 0 then
		tag = tag .. trans("role_trans") .. " "
	end
	if role & ROLE_PLACE ~= 0 and sMario.placement and sMario.placement <= 10 then
		if sMario.placement <= 3 then
			tag = tag .. trans("place_" .. sMario.placement) .. " "
		else
			tag = tag .. trans("place", sMario.placement) .. " "
		end
	end
	if role & ROLE_PLACE_ASN ~= 0 and sMario.placementASN then
		if sMario.placementASN <= 4 then
			tag = tag .. trans("place_asn_" .. sMario.placementASN) .. " "
		else
			tag = tag .. trans("place_asn") .. " "
		end
	end
	if tag ~= "" then
		tag = tag:sub(1, tag:len() - 1)
	end
	return tag
end
function get_true_roles()
	return myRoles
end
function reset_roles()
	gPlayerSyncTable[0].roles = myRoles
end
local placement = {
	[727325076696989857] = -1,
	[452585486389870592] = 1,
	[451375514977042432] = 2,
	[590250114606432304] = 3,
	[376426041788465173] = 4,
	[541396312608866305] = 5,
	[698849755274543204] = 6,
	[361984642590441474] = 7,
	[207244001575698432] = 8,
	ClassicMario64 = 9,
	[249651355889696768] = 10,
	[584329002689363968] = 12,
	[463343811712516106] = 12,
	[1092350568657342505] = 15,
	[489114867215630336] = 16,
	[799106550874243083] = 17,
	[636329822217306133] = 18,
	[990768765652308058] = 22,
	[723015866308100116] = 24,
	[311844589625671680] = 25,
	[556930233014681631] = 26,
	[603685436623421470] = 26,
	[1030290952948043777] = 28,
	[928208159561097236] = 29,
	[467062566254804992] = 29,
	[1035560250566250576] = 32,
	[254732815168569345] = 33,
	[426101681240145930] = 34,
	[1000555727942865036] = 37,
	[864893204054671361] = 41,
	[870107137387397151] = 45,
	[330408854292791298] = 46,
	[461771557531025409] = 46,
	[593234727377305611] = 54,
	[185565083060011013] = 65,
	[711927097890701382] = 70,
	[346023014216892417] = 73,
	[825233181741154324] = 75,
	[246662491017445376] = 76,
	[778591302555009064] = 76
}
local placement_asn = {}
function assign_place(discordID)
	if discordID ~= 0 then
		return placement[discordID] or 9999
	else
		return placement[gNetworkPlayers[0].name] or 9999
	end
end
function assign_place_asn(discordID)
	if discordID ~= 0 then
		return placement_asn[discordID] or 9999
	else
		return placement_asn[gNetworkPlayers[0].name] or 9999
	end
end
