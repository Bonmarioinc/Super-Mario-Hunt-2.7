-- Removed due to deprecation of the function used to make this work
_G.mhVersion = "v2.7" -- version string