-- this file now handles settings (saving/loading, listing, etc.)

local settings = { "mhMode", "runnerLives", "starMode", "runTime", "allowSpectate", "weak",
    "gameAuto", "dmgAdd", "anarchy", "nerfVanish", "firstTimer", "allowStalk", "stalkTimer", "starRun", "noBowser",
    "countdown", "doubleHealth", "voidDmg", "freeRoam", "starHeal", "starSetting", "starStayOld", "spectateOnDeath",
    "maxShuffleTime", "confirmHunter", "huntersWinEarly", "maxGlobalTalk" }
local settingName = { "menu_gamemode", "menu_run_lives", "menu_star_mode", "menu_time", "menu_allow_spectate",
    "menu_weak",
    "menu_auto", "menu_dmgAdd", "menu_anarchy", "menu_nerf_vanish", "menu_first_timer", "menu_allow_stalk",
    "menu_stalk_timer", "menu_category",
    "menu_defeat_bowser", "menu_countdown", "menu_double_health", "menu_voidDmg", "menu_free_roam", "menu_star_heal",
    "menu_star_setting", "menu_star_stay_old", "menu_spectate_on_death", "menu_shuffle", "menu_confirm_hunter", "menu_hunters_win_early", "menu_global_chat" }

local settings_list = { "mhMode", "campaignCourse", "starRun", "freeRoam", "runnerLives", "runTime", "nerfVanish", "weak",
    "dmgAdd",
    "anarchy", "firstTimer", "allowSpectate", "allowStalk", "doubleHealth", "voidDmg", "starHeal", "starSetting",
    "starStayOld", "spectateOnDeath", "maxShuffleTime", "confirmHunter", "huntersWinEarly", "maxGlobalTalk" }
local settingName_list = { "menu_gamemode", "menu_campaign", "menu_category", "menu_free_roam", "menu_run_lives",
    "menu_time",
    "menu_nerf_vanish", "menu_weak", "menu_dmgAdd", "menu_anarchy", "menu_first_timer", "menu_allow_spectate",
    "menu_allow_stalk", "menu_double_health", "menu_voidDmg", "menu_star_heal", "menu_star_setting",
    "menu_star_stay_old", "menu_spectate_on_death", "menu_shuffle", "menu_confirm_hunter", "menu_hunters_win_early", "menu_global_chat" }

local settings_mini_only = { "dmgAdd", "gameAuto", "anarchy", "runTime", "runnerLives" }
local settings_mys_only = { "dmgAdd", "gameAuto", "anarchy", "runTime", "runnerLives", "allowSpectate", "allowStalk",
    "doubleHealth", "spectateOnDeath" }
local settings_mys_force = { ["allowSpectate"] = false, ["allowStalk"] = false }
local settings_mys_force_name = { ["menu_allow_spectate"] = false, ["menu_allow_stalk"] = false }

local GST = gGlobalSyncTable

-- load saved settings for host
function load_settings(prevMode, starOnly)
    if not network_is_server() then return end

    local append
    local lifeOnly = false
    local loadSettings = settings
    local loadRomHack = not starOnly
    if (prevMode == 3) ~= (GST.mhMode == 3) then
        loadSettings = settings_mys_only
        if GST.mhMode == 3 then
            append = "mys_"
        elseif GST.mhMode == 2 then
            append = "mini_"
        end
        loadRomHack = false
    elseif (prevMode == 2) ~= (GST.mhMode == 2) then
        loadSettings = settings_mini_only
        if GST.mhMode == 3 then
            append = "mys_"
        elseif GST.mhMode == 2 then
            append = "mini_"
        end
        loadRomHack = false
    elseif prevMode then
        lifeOnly = true
        loadRomHack = false
    end

    for i, setting in ipairs(loadSettings) do
        local toLoad = setting
        local option

        if setting == "runnerLives" and (not starOnly) then
            if GST.mhMode == 1 then
                append = "switch_"
            end
        elseif lifeOnly then
            toLoad = nil
        elseif setting == "starSetting" then
            toLoad = nil
        elseif GST.mhMode == 3 and settings_mys_force[setting] ~= nil then
            toLoad = nil
            option = tostring(settings_mys_force[setting])
        elseif (setting == "runTime") then
            if GST.starMode then
                toLoad = ("neededStars")
            end
        elseif starOnly then
            toLoad = nil
        elseif setting == "gameAuto" and GST.mhMode ~= 2 then
            toLoad = ("stan_" .. setting)
        elseif setting == "spectateOnDeath" and GST.mhMode == 3 then
            toLoad = ("mys_specOnDeath")
        end

        if append and toLoad then
            toLoad = append .. toLoad
            if GST.mhMode == 1 then
                append = ""
            end
        end

        if setting == "dmgAdd" and toLoad then
            option = mod_storage_load("new_" .. toLoad)
            if not option then
                option = mod_storage_load(toLoad)
                if option == "8" then
                    option = "-1"
                end
            end
        elseif setting == "gameAuto" and toLoad then
            option = mod_storage_load(toLoad)
            if option == "99" then
                option = "-1"
            end
        elseif toLoad then
            option = mod_storage_load(toLoad)
        end

        if option then
            if option == "true" then
                GST[setting] = true
            elseif option == "false" then
                GST[setting] = false
            elseif setting == "mhMode" and tonumber(option) == 3 and disable_chat_hook then
                djui_chat_message_create(trans("mysteryhunt_disabled"))
                GST.mhMode = 0
            elseif tonumber(option) then
                GST[setting] = math.floor(tonumber(option))
                if setting == "gameAuto" and GST[setting] == 0 and (GST.mhState == 0 or GST.mhState >= 3) then
                    GST.mhTimer = 0
                end
            end
            print("Loaded:", toLoad, option, GST[setting])
            if starOnly or lifeOnly then break end
        end
    end

    -- special cases
    if loadRomHack then
        local fileName = string.gsub(GST.romhackFile, " ", "_")
        option = mod_storage_load(fileName)
        local optionNoBow = mod_storage_load(fileName .. "_noBow")
        local optionStalk = mod_storage_load(fileName .. "_stalk")
        if option and tonumber(option) then
            GST.starRun = tonumber(option)
        end
        if optionNoBow == "true" then
            GST.noBowser = true
            GST.freeRoam = false
        elseif optionNoBow == "false" then
            GST.noBowser = false
            GST.freeRoam = false
        elseif tonumber(optionNoBow) then
            local num = tonumber(optionNoBow)
            GST.noBowser = num & 1 ~= 0
            GST.freeRoam = num & 2 ~= 0
        end
        if optionStalk == "true" then
            GST.allowStalk = true
        elseif optionStalk == "false" then
            GST.allowStalk = false
        end
    end
end

-- save settings for host
function save_settings()
    if not network_is_server() then return end

    for i, setting in ipairs(settings) do
        local option = GST[setting]

        if setting == "starSetting" or (GST.mhMode == 3 and settings_mys_force[setting] ~= nil) then
            option = nil -- don't save this
        elseif setting == "gameAuto" and GST.mhMode ~= 2 then
            setting = "stan_gameAuto"
        elseif (setting == "dmgAdd" or setting == "anarchy" or setting == "runTime" or setting == "runnerLives") then
            if GST.mhMode == 2 then
                setting = "mini_" .. setting
            elseif GST.mhMode == 3 then
                setting = "mys_" .. setting
                if setting == "mys_runTime" and GST.starMode then
                    setting = "mys_neededStars"
                end
            elseif setting == "runnerLives" and GST.mhMode == 1 then
                setting = "switch_runnerLives"
            end
            
            if setting == "runTime" and GST.starMode then
                setting = "neededStars"
            end
        elseif setting == "spectateOnDeath" and GST.mhMode == 3 then
            setting = "mys_specOnDeath"
        end

        if setting == "dmgAdd" then
            setting = "new_" .. setting
        end

        if option ~= nil then
            print("Saved:", setting, option, type(option))
            if option == true then
                mod_storage_save(setting, "true")
            elseif option == false then
                mod_storage_save(setting, "false")
            elseif tonumber(option) then
                mod_storage_save(setting, tostring(math.floor(option)))
            end
        end
    end
    -- special cases
    option = GST.starRun
    local optionNoBow = 0
    optionNoBow = optionNoBow | ((GST.noBowser and 1) or 0)
    optionNoBow = optionNoBow | ((GST.freeRoam and 2) or 0)
    local optionStalk = GST.allowStalk
    local fileName = string.gsub(GST.romhackFile, " ", "_")
    if fileName ~= "custom" and option then
        mod_storage_save(fileName, tostring(option))
        if (not ROMHACK or not ROMHACK.no_bowser) and (optionNoBow ~= 0 or mod_storage_load(fileName .. "_noBow")) then
            mod_storage_save(fileName .. "_noBow", tostring(optionNoBow))
        end
        if (ROMHACK and optionStalk ~= ROMHACK.stalk) or mod_storage_load(fileName .. "_stalk") then
            mod_storage_save(fileName .. "_stalk", tostring(optionNoBow))
        end
    end
end

-- loads default settings for host
function default_settings()
    setup_hack_data(true, false, OmmEnabled)

    GST.starMode = false
    if GST.mhMode == 1 then
        GST.runnerLives = 0
        GST.runTime = 7200
        GST.anarchy = 0
        GST.dmgAdd = 0
        GST.spectateOnDeath = false
        GST.allowSpectate = true
    elseif GST.mhMode == 2 then
        GST.runnerLives = 0
        GST.runTime = 9000
        GST.anarchy = 1
        GST.dmgAdd = 2
        GST.spectateOnDeath = false
        GST.allowSpectate = true
    elseif GST.mhMode == 3 then
        GST.runnerLives = 1
        GST.runTime = 7200
        GST.anarchy = 1
        GST.dmgAdd = -1
        GST.spectateOnDeath = true
        GST.allowSpectate = false
    else
        GST.runnerLives = 1
        GST.runTime = 7200
        GST.anarchy = 0
        GST.dmgAdd = 0
        GST.spectateOnDeath = false
        GST.allowSpectate = true
    end

    GST.weak = false
    if GST.gameAuto ~= 0 and (GST.mhState == 0 or GST.mhState == 5) then
        GST.mhTimer = 0
    end
    GST.gameAuto = 0
    GST.campaignCourse = 0
    GST.nerfVanish = true
    GST.firstTimer = true
    GST.countdown = 300
    GST.doubleHealth = false
    GST.voidDmg = 3
    GST.freeRoam = false
    GST.starHeal = false
    GST.stalkTimer = 150
    GST.starStayOld = true
    GST.maxShuffleTime = 0
    GST.maxGlobalTalk = 2700
    GST.confirmHunter = true
    GST.huntersWinEarly = false
    return true
end

-- lists every setting
function list_settings()
    local displayNum = 0
    for i, setting in ipairs(settings_list) do
        local name = settingName_list[i]
        local value = GST[setting]
        name, value = get_setting_as_string(name, value, true)

        if value then
            displayNum = displayNum + 1
            if name then
                djui_chat_message_create(name .. ": " .. value)
            else
                djui_chat_message_create(value)
            end
        end
    end
    if displayNum > 10 then
        djui_chat_message_create(trans("scroll_up"))
    end
end

-- used for list settings and whenever a setting is changed
function get_setting_as_string(name, value, listing)
    local transName = true
    if GST.mhMode == 3 and settings_mys_force_name[name] ~= nil then
        value = nil
    elseif name == "menu_gamemode" then -- gamemode
        if value == 0 then
            value = "\\#00ffff\\Normal"
        elseif value == 1 then
            value = "\\#5aff5a\\Swap"
        elseif value == 2 then
            value = "\\#ffff5a\\Mini"
        elseif value == 3 then
            value = "\\#b45aff\\Mystery"
        else
            value = "INVALID: " .. tostring(value)
        end
        if GST.gameAuto ~= 0 then
            local auto = ""
            if GST.gameAuto == -1 then
                auto = " \\#5aff5a\\(Auto)"
            elseif GST.gameAuto == 1 then
                auto = " \\#00ffff\\(Auto, 1 " .. trans("runner") .. ")"
            elseif GST.gameAuto > 1 then
                auto = " \\#00ffff\\(Auto, " .. GST.gameAuto .. " " .. trans("runners") .. ")"
            elseif GST.gameAuto == -3 then
                auto = " \\#ff5a5a\\(Auto, 1 " .. trans("hunter") .. ")"
            else
                local num = -GST.gameAuto - 2
                auto = " \\#ff5a5a\\(Auto, " .. num .. " " .. trans("hunters") .. ")"
            end
            value = value .. auto
        end
    elseif name == "menu_auto" then
        if value == -1 then
            value = " \\#5aff5a\\Auto"
        elseif value == 1 then
            value = " \\#00ffff\\1 " .. trans("runner")
        elseif value == 0 then
            value = false
        elseif value > 1 then
            value = " \\#00ffff\\" .. value .. " " .. trans("runners")
        elseif value == -3 then
            value = " \\#ff5a5a\\1 " .. trans("hunter")
        else
            value = -value - 2
            value = " \\#ff5a5a\\" .. value .. " " .. trans("hunters")
        end
    elseif name == "menu_time" then -- run time or stars needed
        name = nil
        local timeLeft = value
        if GST.mhMode == 2 then
            name = "menu_time"
            local seconds = timeLeft // 30 % 60
            local minutes = (timeLeft // 1800)
            value = "\\#ffff5a\\" .. string.format("%d:%02d", minutes, seconds)
        elseif GST.starMode then
            value = trans("stars_left", timeLeft)
        else
            timeLeft = timeLeft + 29
            local seconds = timeLeft // 30 % 60
            local minutes = (timeLeft // 1800)
            value = trans("time_left", minutes, seconds)
        end
    elseif name == "menu_anarchy" then -- team attack / hunters know team
        if GST.mhMode == 3 then
            name = "menu_know_team"
            value = (value ~= 3)
        elseif value == 3 then
            value = true
        elseif value == 1 then
            value = "\\#00ffff\\" .. trans("runners")
        elseif value == 2 then
            value = "\\#ff5a5a\\" .. trans("hunters")
        else
            value = false
        end
    elseif name == "menu_category" then -- category
        if GST.mhMode ~= 2 then
            local numVal = value
            if value == -1 then
                value = "\\#5aff5a\\Any%"
            else
                value = "\\#ffff5a\\" .. value .. " Star"
            end
            if GST.noBowser and numVal > 0 then
                value = value .. "\\#ff5a5a\\" .. " (No Bowser)"
            end
        else
            value = nil
        end
    elseif name == "menu_defeat_bowser" then
        local bad = ROMHACK["badGuy_" .. lang] or ROMHACK.badGuy or "Bowser"
        name = trans(name, bad)
        transName = false
        value = not value
    elseif (name == "menu_campaign") then -- minihunt campaign
        if GST.mhMode == 2 then
            if value == 0 then value = false end
        else
            value = nil
        end
    elseif name == "menu_first_timer" then -- leader death timer
        if GST.mhMode ~= 2 then
            value = nil
        end
    elseif name == "menu_dmgAdd" or name == "menu_voidDmg" then
        if value == -1 then
            value = "\\#ff5a5a\\OHKO"
        end
    elseif name == "menu_allow_stalk" then
        if GST.mhMode == 2 then
            value = nil
        elseif value and GST.stalkTimer ~= 150 then
            local seconds = GST.stalkTimer // 30 % 60
            local minutes = (GST.stalkTimer // 1800)
            value = trans("on") .. string.format(" (%d:%02d)", minutes, seconds)
        end
    elseif name == "menu_countdown" or name == "menu_stalk_timer" or name == "menu_shuffle" then
        if name == "menu_shuffle" and value == 0 then
            value = false
        elseif name == "menu_countdown" then
            if value == 300 and listing then
                value = nil
            elseif GST.mhMode == 3 then
                name = "menu_grace_period"
            end
        end
        if value then
            local seconds = value // 30 % 60
            local minutes = (value // 1800)
            value = "\\#ffff5a\\" .. string.format("%d:%02d", minutes, seconds)
        end
    elseif name == "menu_free_roam" then
        if GST.mhMode == 2 then value = nil end
    elseif name == "menu_star_setting" then
        if GST.mhMode == 2 then
            value = nil
        elseif value == 0 then
            value = "\\#ff5a5a\\" .. trans("star_leave")
        elseif value == 1 then
            value = "\\#ffff5a\\" .. trans("star_stay")
        elseif value == 2 then
            value = "\\#5aff5a\\" .. trans("star_nonstop")
        end
    elseif name == "menu_star_stay_old" then
        if GST.mhMode == 2 or gServerSettings.stayInLevelAfterStar ~= 0 then value = nil end
    elseif name == "menu_global_chat" then
        if GST.mhMode ~= 3 then
            value = nil
        elseif value == -1 then
            value = false
        elseif value == 0 then
            value = "\\#5aff5a\\Always"
        else
            local seconds = value // 30 % 60
            local minutes = (value // 1800)
            value = "\\#ffff5a\\" .. string.format("%d:%02d", minutes, seconds)
        end
    elseif name == "menu_confirm_hunter" or name == "menu_hunters_win_early" then
        if GST.mhMode ~= 3 then
            value = nil
        end
    end

    if value == true then
        if (not listing) or (name ~= "menu_allow_spectate" and name ~= "menu_first_timer") then
            value = trans("on")
        else
            value = nil
        end
    elseif value == false then
        if (not listing) or (name == "menu_allow_spectate" or name == "menu_nerf_vanish" or name == "menu_first_timer" or name == "menu_confirm_hunter" or name == "menu_hunters_win_early") then
            value = trans("off")
        else
            value = nil
        end
    elseif tonumber(value) then
        value = "\\#ffff5a\\" .. value
    end

    if name and transName then
        name = trans(name)
    end

    return name, value
end

-- displays a message when a setting is changed
function on_setting_changed(tag, oldVal, newVal)
    if oldVal == newVal then return end

    if tag == "menu_gamemode" then
        return on_mode_changed(tag, oldVal, newVal)
    end

    if (not noSettingDisp) and (tag ~= "menu_star_setting" or not OmmEnabled) then
        local name, value, oldvalue
        name, value = get_setting_as_string(tag, newVal)
        name, oldvalue = get_setting_as_string(tag, oldVal)

        if value then
            if name then
                djui_chat_message_create(trans("change_setting"))
                djui_chat_message_create(name .. ": " .. oldvalue .. "\\#dcdcdc\\->" .. value)
            else
                djui_chat_message_create(trans("change_setting"))
                djui_chat_message_create(oldvalue .. "\\#dcdcdc\\->" .. value)
            end
        end
    end

    if tag == "menu_star_heal" then
        gLevelValues.starHeal = newVal
    elseif tag == "menu_star_setting" then
        gServerSettings.stayInLevelAfterStar = newVal
    elseif tag == "menu_star_mode" then
        noSettingDisp = true
        load_settings(nil, true)
    elseif tag == "menu_allow_stalk" then
        if newVal ~= true then
            update_chat_command_description("stalk", "- " .. trans("command_disabled"))
        else
            update_chat_command_description("stalk", trans("stalk_desc"))
        end
    elseif tag == "menu_allow_spectate" then
        if newVal ~= true then
            update_chat_command_description("spectate", "- " .. trans("command_disabled"))
        else
            update_chat_command_description("spectate", trans("spectate_desc"))
        end
    end
end

for i, setting in ipairs(settings) do
    hook_on_sync_table_change(GST, setting, settingName[i], on_setting_changed)
end

-- display the change in mode
function on_mode_changed(tag, oldVal, newVal)
    if oldVal and oldVal ~= newVal then
        if newVal == 0 then
            popup_or_chat(trans("mode_normal"), 1)
        elseif newVal == 1 then
            popup_or_chat(trans("mode_swap"), 1)
        elseif newVal == 2 then
            popup_or_chat(trans("mode_mini"), 1)
        else
            popup_or_chat(trans("mode_mys"), 1)
        end
        noSettingDisp = true

        if currMenu and (currMenu.name == "settingsMenu") then
            menu_reload()
            menu_enter()
        end

        if network_is_server() then
            change_game_mode("", newVal)
        end
    end
end

function popup_or_chat(msg, lines)
    if djui_is_popup_disabled() then
        djui_chat_message_create(msg)
    else
        djui_popup_create(msg, lines)
    end
end
